package finalProject;



/**
 * interface DAO access
 */
public interface DAO {
    public static final String url = "jdbc:mysql://localhost:3306/aurora_charity_clinic";
    public static final String USER = "root";
    public static final String PASSWORD = "Stand25!";

}
